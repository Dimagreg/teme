package com.example.cfr_app

object Routes {
    const val CITY_SELECTION = "city_selection"
    const val TRAIN_PICKER = "train_picker"
    const val APP_INFO = "app_info"
}