Hi! In order to read README.md in Markdown you can use following:

VSCODE: Right Click on README.md -> Open preview

ONLINE: Open https://dillinger.io/ and paste the content of README file.

Thank you!

GRIGORI DMITRII